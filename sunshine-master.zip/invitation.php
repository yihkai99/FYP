
<?php

include 'config.php';
session_start();
$user_name = $_SESSION['user_name'];
$user_id = $_SESSION['user_id'];

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Twibbon</title>
   <link href="css/bootstrap.css" rel="stylesheet">
   <link rel="stylesheet" href="css/owl.carousel.min.css">
   <link rel="stylesheet" href="css/magnific-popup.css">
   <link rel="stylesheet" href="css/font-awesome.min.css">
   <link rel="stylesheet" href="css/themify-icons.css">
   <link rel="stylesheet" href="css/nice-select.css">
   <link rel="stylesheet" href="css/flaticon.css">
   <link rel="stylesheet" href="css/animate.css">
   <link rel="stylesheet" href="css/header.css">
   <link rel="stylesheet" href="css/bootsrap.css">
   <link rel="stylesheet" href="css/bootsrap.min.css">

    <script src = "https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js">
    </script>
    <script src = "https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.js">
    
    </script>
<style>
  .card{
  width: 1000px;
  margin: auto;
  padding: 10px 10px 0px 10px;
}
.card h2{
  margin: 0 0 6px 0;
  text-align: center;
}
.card .twibbon{
  width: 450px;
  height: 450px;
  margin: auto;
  position: relative;
}
img#twibbon{
  width: 450px;
  height: 650px;
  margin-top:-12px;

}

img#photo{
  z-index: -1;
  position: absolute;
}

#apple {
  margin-top: 40px;
  width: 400px;
  padding: 5px 0px;
  position: relative;
}


#apple h2{
  margin: 0px;
  font-size: 22px;
  position: relative;
}

#apple .left{
  text-align: left;
  margin-top: -110px;
  position: relative;
  margin-left: 35px;
}


#apple .center{
  text-align: center;
  font-size:25px;
  margin-top: 12px;
  position: relative;
}


#apple .right{
  text-align: left;
  position: relative;
  margin-top: 40px;
  margin-left:315px;
}

.button_1{
  display: block;
  margin: 105px auto;
  width: 400px;
  padding: 5px 0;
  font-size: 18px;

}
  </style>

  </head>
  <body>
    <!-- header-->
 <header>
        <div class="header-area ">
            <div id="sticky-header" class="main-header-area">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-3 col-lg-3">
                            <div class="logo-img">
                                <a href="demo.php">
                                    <img src="img/logo.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="col-xl-9 col-lg-9">
                            <div class="main-menu  d-none d-lg-block">
                                <nav>
                                    <ul id="navigation">
                                        <li><a class="active" href="index.php">home</a></li>
                                        <li><a href="card_template.php">Invitation Card <i class="ti-angle-down"></i></a>
                                            <ul class="submenu">
                                                <li><a href="invitation.php">RSVP</a></li>
                                                <li><a href="upload_file.php">Send invitation_card</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="guest_list.php">Wedding Guest List</a></li>
                                        <li><a href="table.php">Table Seating Chart</a></li>
                                        <li><a href="#">Vendor <i class="ti-angle-down"></i></a>
                                            <ul class="submenu">
                                                <li><a href="restaurant.php">Restaurant</a></li>
                                                <li><a href="Photographer.php">Photographer</a></li>
                                            </ul>
                                        </li>
                                        
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="bradcam_area text-center bradcam_bg overlay3">
   <div class="bradcam_text">
       <h3> Invitation Card </h3>
   </div>
</div>
    </header>
        <?php

    $query=mysqli_query($conn,"SELECT * FROM booking WHERE name ='$user_name'");

    ?>
        <div class="twibbon">
        <?php
    if (isset($_POST['send'])) {
        $selected_card = $_POST['selected_card'];

    }
    ?>
        <br>
        Photo <input type="file" id="photoimg" value=""required> <br>
        Width <input type="text" id = "width" value="100%">
        Height <input type="text" id = "height" value="100%">
        Top <input type="text" id = "top" value="0px">
        Left <input type="text" id = "left" value="0px">
        <br>
        <br>
        Text Color <input type="text" id="text" value="black">
        Owner  <input type="text" id="owner" value="Owner">
        To  <input type="text" id="to" value="To">
        Message <input type="text" id="message" value="Message">
        From <input type="text" id="from" value="<?php echo $user_name; ?>"readonly>

        <hr>


        <h2 style="color:black; padding-left:860px;">Pick A Photo</h2>
        <div class="card">
        <div class="twibbon">
            <img src="images/<?php echo $selected_card ?>" id = "twibbon" alt="">
            <img src="" id = "photo" alt="" required>
            <h2 class = "owner" id = "h2owner"style="text-align: center; font-size: 20px;  margin-top:-355px; color:black; "></h2>
        </div>
        
        <div class="container " id="apple">
        <br/>
        <br/>
            <h2 class = "left" id = "h2to"></h2>
            <p class = "center" id = "pmessage"></p>
            <h2 class="right" style="" id="h2from"></h2>
            <br/>
        </div>
    </div>
    <button type="button" class="button_1" id="download" style="margin-left: 754px;">Download
    </button>

        <script type="text/javascript">
        var photoimg = "";

        // Upload image to the directory
        $(document).ready(function () {
            $('#photoimg').change(function () {
                var formData = new FormData();
                var files = $('#photoimg')[0].files;
                formData.append('photo', files[0]);
                $.ajax({
                    url: "upload.php",
                    type: "POST",
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function (response) {
                        photoimg = response;
                    }
                });
            });
        });

        // Real-time preview twibbon
        setInterval(function () {
            preview();
        }, 0);


        function checkRequiredFields() {
        var isPhotoFilled = photoimg !== "";
        var isTextFilled = $('#text').val() !== "" && $('#from').val() !== "" && $('#message').val() !== "" && $('#to').val() !== "" && $('#owner').val() !== "";

        // Enable or disable the download button based on required fields
        $('#download').prop('disabled', !(isPhotoFilled && isTextFilled));
    }
        function preview() {
            var twibbonimg = $('#twibbonimg').val();
            var width = $('#width').val();
            var height = $('#height').val();
            var top = $('#top').val();
            var left = $('#left').val();
            var text = $('#text').val();
            var from = $('#from').val();
            var message = $('#message').val();
            var to = $('#to').val();
            var owner = $('#owner').val();

            
            $('#photo').css("width", width);
            $('#photo').css("height", height);
            $('#photo').css("top", top);
            $('#photo').css("left", left);
            $("#photo").attr("src", photoimg);
            $('#twibbon').attr("src", twibbonimg);
            $('.card').css("color", text);
            $('#h2from').text(from);
            $('#pmessage').text(message);
            $('#h2to').text(to);
            $('#h2owner').text(owner);
            
        }
    
   // Download twibbon
   $("#download").on('click', function(){
    var element = $(".card");
    html2canvas(element, {
        onrendered: function(canvas) {
            var imageData = canvas.toDataURL("image/png");

            // Create an anchor element to trigger the download
            var downloadLink = document.createElement('a');
            downloadLink.href = imageData;
            downloadLink.download = '<?php echo $user_name ?>_invitation.png';
            
            // Append the anchor element to the body and simulate a click
            document.body.appendChild(downloadLink);
            downloadLink.click();

            // Remove the anchor element from the body
            document.body.removeChild(downloadLink);

            // Redirect to upload_file.php
            window.location.replace('upload_file.php');
        }
    });
});


</script>

</div>
 <!-- footer_start -->
 <footer class="footer">
      <div class="footer_top">
          <div class="container">
              <div class="row">
                  <div class="col-xl-12">
                      <div class="quick_links">
                          <ul>
                              <li><a href="#">Home</a></li>
                              <li><a href="#">Our Story</a></li>
                              <li><a href="#">Gallery</a></li>
                              <li><a href="#">Accommodation</a></li>
                              <li><a href="#">Contact</a></li>
                          </ul>
                      </div>
                  </div>
                </div>
              </div>
        </div>
      
  </footer>
  <!-- footer_end -->

   <!-- JS here -->
   <script src="js/vendor/modernizr-3.5.0.min.js"></script>
   <script src="js/vendor/jquery-1.12.4.min.js"></script>
   <script src="js/popper.min.js"></script>
   <script src="js/bootstrap.min.js"></script>
   <script src="js/owl.carousel.min.js"></script>
   <script src="js/isotope.pkgd.min.js"></script>
   <script src="js/ajax-form.js"></script>
   <script src="js/waypoints.min.js"></script>
   <script src="js/jquery.counterup.min.js"></script>
   <script src="js/imagesloaded.pkgd.min.js"></script>
   <script src="js/scrollIt.js"></script>
   <script src="js/jquery.scrollUp.min.js"></script>
   <script src="js/wow.min.js"></script>
   <script src="js/nice-select.min.js"></script>
   <script src="js/jquery.slicknav.min.js"></script>
   <script src="js/jquery.magnific-popup.min.js"></script>
   <script src="js/plugins.js"></script>

   <!--contact js-->
   <script src="js/contact.js"></script>
   <script src="js/jquery.ajaxchimp.min.js"></script>
   <script src="js/jquery.form.js"></script>
   <script src="js/jquery.validate.min.js"></script>
   <script src="js/mail-script.js"></script>

   <script src="js/main.js"></script>


    </script>
  </body>
</html>