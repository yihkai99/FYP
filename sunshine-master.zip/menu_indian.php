
<?php

include 'config.php';
session_start();
$user_name = $_SESSION['user_name'];
$user_id = $_SESSION['user_id'];

$id=@$_GET['id'];

?>

<!doctype html>
<html class="no-js" lang="zxx">

<head>
   <meta charset="utf-8">
   <meta http-equiv="x-ua-compatible" content="ie=edge">
   <title>Weeding</title>
   <meta name="description" content="">
   <meta name="viewport" content="width=device-width, initial-scale=1">

   <!-- <link rel="manifest" href="site.webmanifest"> -->
   <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">
   <!-- Place favicon.ico in the root directory -->

   <!-- CSS here -->
   <link rel="stylesheet" href="css/bootstrap.min.css">
   <link href="css/bootstrap.css" rel="stylesheet">
   <link rel="stylesheet" href="css/owl.carousel.min.css">
   <link rel="stylesheet" href="css/magnific-popup.css">
   <link rel="stylesheet" href="css/font-awesome.min.css">
   <link rel="stylesheet" href="css/themify-icons.css">
   <link rel="stylesheet" href="css/nice-select.css">
   <link rel="stylesheet" href="css/flaticon.css">
   <link rel="stylesheet" href="css/animate.css">
   <link rel="stylesheet" href="css/slicknav.css">
   <link rel="stylesheet" href="css/style.css">


   <!-- <link rel="stylesheet" href="css/responsive.css"> -->
</head>
<style>
    /* restaurant */
.price-gd-top {
  text-align: center;
  position: relative;
}

.price-gd-top p
{
  margin-top: 50px ;
}
.price-gd-top h4 {
  font-size: 1.5em;
  color: #fff;
  padding: 0.4em 1em;
  background: #0f2453;
  font-weight: 300;
  position: absolute;
  top: 9.6em;
  right: 0em;
}
.price-selet p {
    padding: 0.2em 0em 0em 0em;
  font-size: 1.7em;
  text-align:center;
}

.price-gd-bottom {
  background: #fff;
  text-align: center;
  padding: 1.8em 0em 1em;
}
.price-gd-top .teng{
  height: 300px;
  width: 340px;
}

.price-gd-top .teng img  {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.price-selet {
  padding: 1em 0em;
  text-align: center;
  background: #fff;
}
.price-selet a {
  font-size: 1.1em;
  color: #fff;
  display: block;
}
.price-selet a {
  font-size: 0.9em;
  color: #000000;
  display: inline-block;
  padding: 0.5em 2em;
  background: #ffce14;
  text-decoration: none;
  border: 2px solid #ecbf11;
}
.price-block {
  box-shadow: 0px 0px 2px 1px rgba(0,0,0,0.15);
  transition: 0.5s all;
  -webkit-transition: 0.5s all;
  -moz-transition: 0.5s all;
  -o-transition: 0.5s all;
}
.price-block:hover,.w3layouts-pricing:hover,.w3-agileits-vpn-grid:hover {
  transform: scale(1.1);
  -webkit-transform: scale(1.1);
  -moz-transform: scale(1.1);
  -o-transform: scale(1.1);
  -ms-transform: scale(1.1);
  z-index: 1;
}
    </style>

<body>
   <!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->

 <!-- header-->
 <header>
   <div class="header-area ">
       <div id="sticky-header" class="main-header-area">
           <div class="container">
               <div class="row align-items-center">
                   <div class="col-xl-3 col-lg-3">
                       <div class="logo-img">
                           <a href="index.html">
                               <img src="img/logo.png" alt="">
                           </a>
                       </div>
                   </div>
                   <div class="col-xl-9 col-lg-9">
                       <div class="main-menu  d-none d-lg-block">
                            <nav>
                                <ul id="navigation">
                                    <li><a class="active" href="index.php">home</a></li>
                                    <li><a href="card_template.php">Invitation Card <i class="ti-angle-down"></i></a>
                                        <ul class="submenu">
                                            <li><a href="invitation.php">RSVP</a></li>
                                            <li><a href="upload_file.php">Send invitation_card</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="guest_list.php">Wedding Guest List</a></li>
                                    <li><a href="table.php">Table Seating Chart</a></li>
                                    <li><a href="#">Vendor <i class="ti-angle-down"></i></a>
                                        <ul class="submenu">
                                            <li><a href="restaurant.php">Restaurant</a></li>
                                            <li><a href="Photographer.php">Photographer</a></li>
                                        </ul>
                                    </li>
                                    
                                </ul>
                            </nav>
                       </div>
                   </div>
                   <div class="col-12">
                       <div class="mobile_menu d-block d-lg-none"></div>
                   </div>
               </div>
           </div>
       </div>
   </div>
</header>
<!--/ header-->

<!-- bradcam_area  -->
<div class="bradcam_area text-center bradcam_bg overlay3">
   <div class="bradcam_text">
       <h3> Our Restaurant Menu  </h3>
   </div>
</div>
<!-- products and rates -->
<div class="plans-section" id="rooms">
   <div class="container">
</br>
</br>

<?php 
$query=mysqli_query($conn,"SELECT * FROM restaurant WHERE rest_id = '$id'");
while($row=mysqli_fetch_array($query))
{
    $restaurant_menu=$row['restaurant_menu'];
    $restaurant_price=$row['restaurant_price'];

    $menu = explode(' , ', $restaurant_menu);
    $menus = $menu;

    $price = explode(' , ', $restaurant_price);
    $prices = $price;

    for ($a=0; $a<3 ; $a++){
 
?>

<div class="col-md-4 price-grid">
    <div class="price-block agile">
        <div class="price-gd-top">                     
            <?php if (file_exists("images/{$menus[$a]}")) { ?>
                <img src="images/<?php echo $menus[$a]; ?>" class="img-responsive" />
            <?php } else { ?>
                <p>No Image Available</p>
            <?php } ?>
        </div>
        <div class="price-selet">
            <div class="row">
                <div class="col">
                    <p>Per table</p>	  
                    <p><?php echo $prices[$a]; ?> </p>	  
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <a href="booking.php?id=<?php echo $id; ?>&menu=<?php echo $menus[$a]; ?>&price=<?php echo $prices[$a]; ?>">Place a Booking</a>
                </div>
            </div>
        </div>                     
    </div>
</div>

<?php    
        
    } 
} 
?>

</div>

               
<!--// Products and rates -->

   <!-- footer_start -->
   <footer class="footer">
      <div class="footer_top">
          <div class="container">
              <div class="row">
                  <div class="col-xl-12">
                      <div class="quick_links">
                          <ul>
                              <li><a href="#">Home</a></li>
                              <li><a href="#">Our Story</a></li>
                              <li><a href="#">Gallery</a></li>
                              <li><a href="#">Accommodation</a></li>
                              <li><a href="#">Contact</a></li>
                          </ul>
                      </div>
                  </div>
              </div>
              </div>
          </div>
      </div>
      <div class="copy-right_text">
          <div class="container">
              <div class="footer_border"></div>
              <div class="row">
                  <div class="col-xl-12">
                      
                  </div>
              </div>
          </div>
      </div>
  </footer>
  <!-- footer_end -->

   <!-- JS here -->
   <script src="js/vendor/modernizr-3.5.0.min.js"></script>
   <script src="js/vendor/jquery-1.12.4.min.js"></script>
   <script src="js/popper.min.js"></script>
   <script src="js/bootstrap.min.js"></script>
   <script src="js/owl.carousel.min.js"></script>
   <script src="js/isotope.pkgd.min.js"></script>
   <script src="js/ajax-form.js"></script>
   <script src="js/waypoints.min.js"></script>
   <script src="js/jquery.counterup.min.js"></script>
   <script src="js/imagesloaded.pkgd.min.js"></script>
   <script src="js/scrollIt.js"></script>
   <script src="js/jquery.scrollUp.min.js"></script>
   <script src="js/wow.min.js"></script>
   <script src="js/nice-select.min.js"></script>
   <script src="js/jquery.slicknav.min.js"></script>
   <script src="js/jquery.magnific-popup.min.js"></script>
   <script src="js/plugins.js"></script>

   <!--contact js-->
   <script src="js/contact.js"></script>
   <script src="js/jquery.ajaxchimp.min.js"></script>
   <script src="js/jquery.form.js"></script>
   <script src="js/jquery.validate.min.js"></script>
   <script src="js/mail-script.js"></script>

   <script src="js/main.js"></script>



</body>

</html>