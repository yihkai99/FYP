<?php
session_start();
$user_name=$_SESSION['user_name'];
$user_id = $_SESSION['user_id'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user_db";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
     die("Connection failed: " . mysqli_connect_error());
}
?>


<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Weeding</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- <link rel="manifest" href="site.webmanifest"> -->
    <!-- <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png"> -->
    <!-- Place favicon.ico in the root directory -->

    <!-- CSS here -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/themify-icons.css">
    <link rel="stylesheet" href="css/nice-select.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/gijgo.css">
    <link rel="stylesheet" href="css/slicknav.css">
    <link rel="stylesheet" href="css/style.css">
    <!-- <link rel="stylesheet" href="css/responsive.css"> -->
<style>
    .dashboard table, .dashboard td, .dashboard thead {
        border: 1px solid black;
        padding: 20px; /* Add padding here */
    }

.dashboard table {
  margin:auto;
  border-collapse: collapse;

}
img{
    width:250px;
    height:75%;
}
</style>
</head>

<body>
    <!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->

    <!-- header-->
    <header>
        <div class="header-area ">
            <div id="sticky-header" class="main-header-area">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-3 col-lg-3">
                            <div class="logo-img">
                                <a href="demo.php">
                                    <img src="img/logo.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="col-xl-9 col-lg-9">
                            <div class="main-menu  d-none d-lg-block">
                            <nav>
                                <ul id="navigation">
                                    <li><a class="active" href="index.php">home</a></li>
                                    <li><a href="card_template.php">Invitation Card <i class="ti-angle-down"></i></a>
                                        <ul class="submenu">
                                            <li><a href="invitation.php">RSVP</a></li>
                                            <li><a href="upload_file.php">Send invitation_card</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="guest_list.php">Wedding Guest List</a></li>
                                    <li><a href="table.php">Table Seating Chart</a></li>
                                    <li><a href="#">Vendor <i class="ti-angle-down"></i></a>
                                        <ul class="submenu">
                                            <li><a href="restaurant.php">Restaurant</a></li>
                                            <li><a href="Photographer.php">Photographer</a></li>
                                        </ul>
                                    </li>
                                    <a href="logout.php" class="logout-link">
                                        <i class="fas fa-sign-out-alt"></i>
                                        <span>Log Out</span>
                                    </a>

                                </div>
                                </ul>
                            </nav>

                            </div>
                        </div>
                        <div class="col-12">
                            <div class="mobile_menu d-block d-lg-none"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!--/ header-->
    
    <?php
$date = '-';
$time = '-';
$restaurant_name = '-';
$status = '-';
$table = '-';
$photographer_name = '-';
$status = '-';

$query = mysqli_query($conn, "SELECT * FROM booking WHERE name ='$user_name'");
while ($row = mysqli_fetch_array($query)) {
    if (
        isset($row['date']) && !empty($row['date']) &&
        isset($row['time']) && !empty($row['time']) &&
        isset($row['menu']) && !empty($row['menu']) &&
        isset($row['status']) && !empty($row['status']) &&
        isset($row['table']) && !empty($row['table']) &&
        isset($row['photographer']) && !empty($row['photographer']) &&
        isset($row['status']) && !empty($row['status'])
    ) {
        $date = $row['date'];
        $time = $row['time'];
        $restaurant = $row['restaurant'];
        $status = $row['status'];
        $table = $row['table'];
        $photographer = $row['photographer'];
        $status = $row['status'];
    }

}
?>

    <!-- slider_area -->
    <div class="slider_area">
    <div class="slider_area_inner slider_bg_1 overlay2">
        <div class="slider_text text-center">
            <div class="text_inner">
                <img src="img/banner/ornaments.png" alt="">
                <?php
                $date = '-';
                $time = '-';

                $query = mysqli_query($conn, "SELECT * FROM booking WHERE name ='$user_name'");
                while ($row = mysqli_fetch_array($query)) {
                    if (
                        isset($row['date']) && !empty($row['date']) &&
                        isset($row['time']) && !empty($row['time'])
                    ) {
                        $date = $row['date'];
                        $time = $row['time'];
                    }
                }
                ?>
                <h4><?php echo $date; ?></h4>
                <h3><?php echo $user_name; ?></h3>
                <span><?php echo substr($time, 0, 5); ?></span>
            </div>
        </div>
    </div>
</div>

    <!--/ slider_area -->

    <!-- wedding_countdown -->
<div class="weeding_countdown_area">


    <div class="flowaers_top d-none d-lg-block">
        <img src="img/banner/flower-top.png" alt="">
    </div>
    <div class="flowaers_bottom d-none d-lg-block"style="bottom:33px;">
        <img src="img/banner/flower-bottom.png" alt="">
    </div>
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="section_title text-center">
                    <img src="img/banner/flowers.png" alt="">
                    <h4><?php echo $date; ?></h4>
                    <h3>THE. WEDDING. Countdown</h3>
                    
                    <?php
                        if (isset($time)) {
                            echo "
                            <p id='demo' style='font-family: times-new roman; font-size: 36px; border: 1px solid; font-weight: bold; padding-top: 20px; padding-bottom: 20px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); width: 280px; margin: auto;'></p>
                            ";
                        } else {
                            echo "Time not available";
                        }
                        ?>

                    
                   
                </div>
            </div>
        </div>
    </div>
</div>
<h3 style="text-align:center; font-family: 'Times New Roman', Times, serif; font-size:30px;"> Status Overview </h3>

<div class="dashboard">
        
        <table>
        <?php
            $query = mysqli_query($conn, "SELECT * FROM user_table WHERE name ='$user_name'");

            while ($row = mysqli_fetch_array($query)) {
                $image = $row['image'];
                $user_name = $row['name'];
                echo '<div style="text-align: center;">';
                echo '<img src="images/' . $image . '" alt="profile pic" style="display: block; margin: 0 auto;"/>';
                echo  $user_name ;
                echo '</div>';
            }
        ?>

            <tbody>
        <thead>
        <br/>
            <tr>
            <td> User_name</td>        
            <td> Wedding Date</td>
            <td> Restaurant</td>
            <td> Restaurant Booking Status</td>
            <td> Restaurant Table Seating
            <td> Photographer</td>
            <td> Photographer Booking Status</td>
        </tr>
                    </thead>
                    <?php
                $r2 = mysqli_query($conn,"SELECT *FROM booking WHERE name='$user_name'");
                while($row =mysqli_fetch_array($r2))
                {
                   $restaurant_name=$row['restaurant_name'];
                   $table=$row['table'];
                   $status=$row['status'];
                   $date=$row['date'];
                   $photographer_name = $row['photographer_name'];

            }
               
                echo "<tr>
                    <td>$user_name</td>
                    <td>$date</td>
                    <td>$restaurant_name</td>
                    <td>$status</td>
                    <td>$table</td>
                    <td>$photographer_name</td>
                    <td>$status</td>
                </tr>";
        
                ?>

                    </tbody>
        </table>          
</div>

    <!--/ wedding_countdown -->

  <!-- footer_start -->
  <footer class="footer">
      <div class="footer_top">
          <div class="container">
              <div class="row">
                  <div class="col-xl-12">
                      <div class="quick_links">
                          <ul>
                              <li><a href="#">Home</a></li>
                              <li><a href="#">Our Story</a></li>
                              <li><a href="#">Gallery</a></li>
                              <li><a href="#">Accommodation</a></li>
                              <li><a href="#">Contact</a></li>
                          </ul>
                      </div>
                  </div>
                </div>
              </div>
        </div>
      
  </footer>
  <!-- footer_end -->

   <!-- JS here -->
   <script src="js/vendor/modernizr-3.5.0.min.js"></script>
   <script src="js/vendor/jquery-1.12.4.min.js"></script>
   <script src="js/popper.min.js"></script>
   <script src="js/bootstrap.min.js"></script>
   <script src="js/owl.carousel.min.js"></script>
   <script src="js/isotope.pkgd.min.js"></script>
   <script src="js/ajax-form.js"></script>
   <script src="js/waypoints.min.js"></script>
   <script src="js/jquery.counterup.min.js"></script>
   <script src="js/imagesloaded.pkgd.min.js"></script>
   <script src="js/scrollIt.js"></script>
   <script src="js/jquery.scrollUp.min.js"></script>
   <script src="js/wow.min.js"></script>
   <script src="js/nice-select.min.js"></script>
   <script src="js/jquery.slicknav.min.js"></script>
   <script src="js/jquery.magnific-popup.min.js"></script>
   <script src="js/plugins.js"></script>

   <!--contact js-->
   <script src="js/contact.js"></script>
   <script src="js/jquery.ajaxchimp.min.js"></script>
   <script src="js/jquery.form.js"></script>
   <script src="js/jquery.validate.min.js"></script>
   <script src="js/mail-script.js"></script>

   <script src="js/main.js"></script>
   <!-- Place the script at the bottom of the HTML file -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>


    </script>

    <script>
                        // Set the date we're counting down to
                        
                        var countDownDate = new Date("<?php echo $date; ?>").getTime();

                        // Update the count down every 1 second
                        var x = setInterval(function () {
                            // Get today's date and time
                            var now = new Date().getTime();

                            // Find the distance between now and the count down date
                            var distance = countDownDate - now;

                            // Time calculations for days, hours, minutes, and seconds
                            var days = Math.floor(distance / (1000 * 60 * 60 * 24));
                            var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                            var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                            var seconds = Math.floor((distance % (1000 * 60)) / 1000);

                            // Output the result in an element with id="demo"
                            document.getElementById("demo").innerHTML = days + "d " + hours + "h " +
                                minutes + "m " + seconds + "s ";

                            // If the count down is over, write some text 
                            if (distance < 0) {
                                clearInterval(x);
                                document.getElementById("demo").innerHTML = "EXPIRED";
                            }
                        }, 1000);
                    </script>
                    
  </body>
</html>