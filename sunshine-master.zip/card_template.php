
<?php

include 'config.php';
session_start();
$user_name = $_SESSION['user_name'];
$user_id = $_SESSION['user_id'];

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Twibbon</title>
   <link href="css/bootstrap.css" rel="stylesheet">
   <link rel="stylesheet" href="css/owl.carousel.min.css">
   <link rel="stylesheet" href="css/magnific-popup.css">
   <link rel="stylesheet" href="css/font-awesome.min.css">
   <link rel="stylesheet" href="css/themify-icons.css">
   <link rel="stylesheet" href="css/nice-select.css">
   <link rel="stylesheet" href="css/flaticon.css">
   <link rel="stylesheet" href="css/animate.css">
   <link rel="stylesheet" href="css/header.css">
   <link rel="stylesheet" href="css/bootsrap.css">
   <link rel="stylesheet" href="css/bootsrap.min.css">

    <script src = "https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js">
    </script>
    <script src = "https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.js">
    
    </script>
    <style>
 .box-container .box{
   background-color: var(--white);
   border-radius: .5rem;
   box-shadow: var(--box-shadow);
   border:var(--border);
   padding:2rem;
   padding-top: 1rem;
}

 .box-container .box p{
   padding: .5rem 0;
   line-height: 1.5;
   font-size: 1.8rem;
   color:var(--black);
}
.template img
{
    width:300px;
    height:350px;
}
    </style>
  </head>
  <body>
    <!-- header-->
 <header>
        <div class="header-area ">
            <div id="sticky-header" class="main-header-area">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-3 col-lg-3">
                            <div class="logo-img">
                                <a href="demo.php">
                                    <img src="img/logo.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="col-xl-9 col-lg-9">
                            <div class="main-menu  d-none d-lg-block">
                                <nav>
                                    <ul id="navigation">
                                        <li><a class="active" href="index.php">home</a></li>
                                        <li><a href="card_template.php">Invitation Card <i class="ti-angle-down"></i></a>
                                            <ul class="submenu">
                                                <li><a href="invitation.php">RSVP</a></li>
                                                <li><a href="upload_file.php">Send invitation_card</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="guest_list.php">Wedding Guest List</a></li>
                                        <li><a href="table.php">Table Seating Chart</a></li>
                                        <li><a href="#">Vendor <i class="ti-angle-down"></i></a>
                                            <ul class="submenu">
                                                <li><a href="restaurant.php">Restaurant</a></li>
                                                <li><a href="Photographer.php">Photographer</a></li>
                                            </ul>
                                        </li>
                                        
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div> 
        
        <div class="bradcam_area text-center bradcam_bg overlay3">
   <div class="bradcam_text">
       <h3> Card Template </h3>
   </div>
</div>
    </header>
    <div class="template">
    <div class="row">
        <form method="POST" action="invitation.php">
            <?php
            $query = mysqli_query($conn, "SELECT * FROM invitation_card");

            while ($fetch_accounts = mysqli_fetch_array($query)) {
            ?>
                <div class="col-xl-3 col-lg-3">
                    <div class="box-container">
                        <div class="box">
                            <p> Invitation card Image :</p>
                            <img src="images/<?php echo $fetch_accounts['card_image']; ?>" alt="Invitation Card Image"/>
                            <p> Invitation card Name : <span><?php echo $fetch_accounts['card_name']; ?></span> </p>
                            <input type="radio" name="selected_card" value="<?php echo $fetch_accounts['card_image']; ?>"required> Select This
                            
                        </div>
                    </div>
                </div>
            <?php
            }
            ?>
            <br/>
            <br/>
        </div>
         <button type="submit" name="send" id="button" style="margin-bottom:85px; display:block; margin-left:890px;">Choose this template</button>
        </form>
    </div>
</div>



 <!-- footer_start -->
 <footer class="footer">
      <div class="footer_top">
          <div class="container">
              <div class="row">
                  <div class="col-xl-12">
                      <div class="quick_links">
                          <ul>
                              <li><a href="#">Home</a></li>
                              <li><a href="#">Our Story</a></li>
                              <li><a href="#">Gallery</a></li>
                              <li><a href="#">Accommodation</a></li>
                              <li><a href="#">Contact</a></li>
                          </ul>
                      </div>
                  </div>
                </div>
              </div>
        </div>
      
  </footer>
  <!-- footer_end -->

   <!-- JS here -->
   <script src="js/vendor/modernizr-3.5.0.min.js"></script>
   <script src="js/vendor/jquery-1.12.4.min.js"></script>
   <script src="js/popper.min.js"></script>
   <script src="js/bootstrap.min.js"></script>
   <script src="js/owl.carousel.min.js"></script>
   <script src="js/isotope.pkgd.min.js"></script>
   <script src="js/ajax-form.js"></script>
   <script src="js/waypoints.min.js"></script>
   <script src="js/jquery.counterup.min.js"></script>
   <script src="js/imagesloaded.pkgd.min.js"></script>
   <script src="js/scrollIt.js"></script>
   <script src="js/jquery.scrollUp.min.js"></script>
   <script src="js/wow.min.js"></script>
   <script src="js/nice-select.min.js"></script>
   <script src="js/jquery.slicknav.min.js"></script>
   <script src="js/jquery.magnific-popup.min.js"></script>
   <script src="js/plugins.js"></script>

   <!--contact js-->
   <script src="js/contact.js"></script>
   <script src="js/jquery.ajaxchimp.min.js"></script>
   <script src="js/jquery.form.js"></script>
   <script src="js/jquery.validate.min.js"></script>
   <script src="js/mail-script.js"></script>

   <script src="js/main.js"></script>


    </script>
  </body>
</html>