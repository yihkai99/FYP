<?php

include 'config.php';
session_start();
$user_name = $_SESSION['user_name'];
$user_id = $_SESSION['user_id'];

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Twibbon</title>
   <link href="css/bootstrap.css" rel="stylesheet">
   <link rel="stylesheet" href="css/owl.carousel.min.css">
   <link rel="stylesheet" href="css/magnific-popup.css">
   <link rel="stylesheet" href="css/font-awesome.min.css">
   <link rel="stylesheet" href="css/themify-icons.css">
   <link rel="stylesheet" href="css/nice-select.css">
   <link rel="stylesheet" href="css/flaticon.css">
   <link rel="stylesheet" href="css/animate.css">
   <link rel="stylesheet" href="css/header.css">
   <link rel="stylesheet" href="css/bootsrap.css">
   <link rel="stylesheet" href="css/bootsrap.min.css">
   <head>
<style>
    * {
        margin: 0;
        padding: 0;
    }

    .hero {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .card {
        width: 400px;
        background: #fff;
        padding: 40px;
        border-radius: 15px;
        text-align: center;
        color: #333;
    }

    .card h1 {
        font-weight: 500;
        color: #000;
    }

    .card img {
        
        margin-left:-296px;
    }

    label {
        display: block;
        width: 250px;
        background: #e3362c;
        color: #fff;
        padding: 12px;
        margin: 10px auto;
        border-radius: 5px;
        cursor: pointer;
    }

    input {
        display: none;
    }
    #button{
  display: block;
  margin: 40px auto;
  width: 80px;
  padding: 5px 0;
  font-size: 18px;

}
</style>
<body>
     <!-- header-->
 <header>
        <div class="header-area ">
            <div id="sticky-header" class="main-header-area">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-3 col-lg-3">
                            <div class="logo-img">
                                <a href="demo.php">
                                    <img src="img/logo.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="col-xl-9 col-lg-9">
                            <div class="main-menu  d-none d-lg-block">
                            <nav>
                                    <ul id="navigation">
                                        <li><a class="active" href="index.php">home</a></li>
                                        <li><a href="#">Invitation Card <i class="ti-angle-down"></i></a>
                                            <ul class="submenu">
                                                <li><a href="invitation.php">RSVP</a></li>
                                                <li><a href="upload_file.php">Send invitation_card</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="guest_list.php">Wedding Guest List</a></li>
                                        <li><a href="table.php">Table Seating Chart</a></li>
                                        <li><a href="#">Vendor <i class="ti-angle-down"></i></a>
                                            <ul class="submenu">
                                                <li><a href="restaurant.php">Restaurant</a></li>
                                                <li><a href="Photographer.php">Photographer</a></li>
                                            </ul>
                                        </li>
                                        
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="bradcam_area text-center bradcam_bg overlay3">
   <div class="bradcam_text">
       <h3> Invitation Card </h3>
   </div>
</div>
    </header>

<div class="hero">
    <div class="card">
    <form action="send_email/send.php" method="POST">
    <h1>Hello <?php echo $user_name; ?></h1>
    <label for="input-file">Update your Invitation Card</label>
    <input type="file" accept="image/jpg,image/png,image/jpeg" id="input-file" name="invite_card" required>

    <!-- Add input fields for multiple guest names and email addresses -->
    <div class="guest-inputs">
        <div class="guest-input">
            <input type="text" class="form-control" name="guest_name[]" placeholder="Please insert your guest_1 name" required>
            <input type="text" class="form-control" name="guest_email[]" placeholder="Please insert your guest_1 email" required>
        </div>
        <br/>
        <div class="guest-input">
            <input type="text" class="form-control" name="guest_name[]" placeholder="Please insert your guest_2 name" required>
            <input type="text" class="form-control" name="guest_email[]" placeholder="Please insert your guest_2 email" required>
        </div>
        <!-- Add more guest-input divs as needed -->
    </div>

    <img id="profile-pic" src="" />

    <input type="submit" name="send" id="button" style="margin-left:116px;" value="Send">
    </div>
</form>

</div>

<!-- footer_start -->
<footer class="footer">
      <div class="footer_top">
          <div class="container">
              <div class="row">
                  <div class="col-xl-12">
                      <div class="quick_links">
                          <ul>
                              <li><a href="#">Home</a></li>
                              <li><a href="#">Our Story</a></li>
                              <li><a href="#">Gallery</a></li>
                              <li><a href="#">Accommodation</a></li>
                              <li><a href="#">Contact</a></li>
                          </ul>
                      </div>
                  </div>
                </div>
              </div>
        </div>
      
  </footer>
  <!-- footer_end -->

   <!-- JS here -->
   <script src="js/vendor/modernizr-3.5.0.min.js"></script>
   <script src="js/vendor/jquery-1.12.4.min.js"></script>
   <script src="js/popper.min.js"></script>
   <script src="js/bootstrap.min.js"></script>
   <script src="js/owl.carousel.min.js"></script>
   <script src="js/isotope.pkgd.min.js"></script>
   <script src="js/ajax-form.js"></script>
   <script src="js/waypoints.min.js"></script>
   <script src="js/jquery.counterup.min.js"></script>
   <script src="js/imagesloaded.pkgd.min.js"></script>
   <script src="js/scrollIt.js"></script>
   <script src="js/jquery.scrollUp.min.js"></script>
   <script src="js/wow.min.js"></script>
   <script src="js/nice-select.min.js"></script>
   <script src="js/jquery.slicknav.min.js"></script>
   <script src="js/jquery.magnific-popup.min.js"></script>
   <script src="js/plugins.js"></script>

   <!--contact js-->
   <script src="js/contact.js"></script>
   <script src="js/jquery.ajaxchimp.min.js"></script>
   <script src="js/jquery.form.js"></script>
   <script src="js/jquery.validate.min.js"></script>
   <script src="js/mail-script.js"></script>

   <script src="js/main.js"></script>


    </script>
  </body>
</html>
</body>
</html>
