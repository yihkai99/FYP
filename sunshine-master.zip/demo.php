<!DOCTYPE html>
<html>
<head>
    <title>Main Page</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" 
          rel="stylesheet" 
          integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" 
          crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6"
          crossorigin="anonymous">
    <style> 
        #menu {
            position: relative;
        }

        .btn1{
            border-radius: 30%;
            padding: 6px;
            width: 400px;
            color: black;
            position: absolute;
            top: 70%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: white;
            box-shadow: 0px 11px 8px #dee2e6; /* Add box shadow */
        }
        .btn2 {
    width: 800px;
    color: black;
    position: absolute;
    top: 200px;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
    font-size: 24px; /* Adjust font size as needed */
    font-weight: bold; /* Adjust font weight as needed */
    margin: 0; /* Remove default margin */
    padding: 10px; /* Add padding if needed */
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3); /* Add text shadow */
}      
    .video video#myvideo{
      width=100px;
      height=500px;

        }
    </style>
</head>
<body>     
    <div id="menu">
    <div class="btn2">
            <h1><center>Welcome to Sunshine Wedding Agency</center></h1>
    </div>
        <video autoplay muted loop width="100%" id="myVideo">
            <source src="video.mp4" type="video/mp4">
            Your browser does not support HTML5 video.
        </video>
        
    </div>
        <button class="btn1"> <a class="nav-link active" aria-current="page" href="register.php" style="margin:auto;">
            <h1><center>Register & Log In Press Here</center></h1>
        </button>
        
    </div>
    
    <!-- Rest of your content here -->
</body>
</html>
