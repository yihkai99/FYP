<?php 
session_start();
if(isset($_SESSION['user_id'])){
session_destroy();}

echo"<script> window.location.replace('demo.php'); </script>";
echo"<script>alert('You have successfully logged out! Thank you.'); </script>";
?>
