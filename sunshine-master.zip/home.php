<?php

include 'config.php';
session_start();
$user_name = $_SESSION['user_name'];
$user_id = $_SESSION['user_id'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>home</title>

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<div class="container1">

   <div class="profile">
    <?php
    $select = mysqli_query($conn, "SELECT * FROM `user_table` WHERE name = '$user_name'") or die('query failed');
    if (mysqli_num_rows($select) > 0) {
        $fetch = mysqli_fetch_assoc($select);
    }
    if (isset($fetch) && $fetch['image'] == '') {
        echo '<img src="images/default-avatar.png">';
    } elseif (isset($fetch)) {
        echo '<img src="uploaded_img/' . $fetch['image'] . '">';
    }
    ?>
    <h3><?php echo isset($fetch) ? $fetch['name'] : ''; ?></h3>
    <a href="index.php" class="btn1">Start to plan your wedding</a>
    <a href="update_profile.php" class="btn1">Update profile</button>
    <a href="logout.php">Logout</a>
</div>


</div>
     

</body>
</html>