<?php

include 'config.php';
session_start();
$user_name = $_SESSION['user_name'];
$user_id = $_SESSION['user_id'];

if (isset($_POST['submit'])) {
    $table_no  = $_POST['table_no'];

    if (isset($_POST['selected_rows']) && is_array($_POST['selected_rows'])) {
        // Retrieve the selected question IDs
        $selectedGuest = $_POST['selected_rows'];

        foreach ($selectedGuest as $guest) {
            $result = mysqli_query($conn, "INSERT INTO table_seating (id, table_no, guest_name, user_name) VALUES ('', '$table_no', '$guest', '$user_name')");
        }
    }
}

?>

<!doctype html>
<html class="no-js" lang="zxx">
<link href="css/bootstrap.css" rel="stylesheet">
   <link rel="stylesheet" href="css/owl.carousel.min.css">
   <link rel="stylesheet" href="css/magnific-popup.css">
   <link rel="stylesheet" href="css/font-awesome.min.css">
   <link rel="stylesheet" href="css/themify-icons.css">
   <link rel="stylesheet" href="css/nice-select.css">
   <link rel="stylesheet" href="css/flaticon.css">
   <link rel="stylesheet" href="css/animate.css">
   <link rel="stylesheet" href="css/header.css">
   <link rel="stylesheet" href="css/bootsrap.css">
   <link rel="stylesheet" href="css/bootsrap.min.css">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Guest list</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="styleshee" href="style.css">
</head>
<style>
* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
}

/* Float four columns side by side */
.column {
  float: left;
  width: 25%;
  padding: 0 10px;
}

/* Remove extra left and right margins, due to padding */
.row {margin: 0 -5px;}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive columns */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
    display: block;
    margin-bottom: 20px;
  }
}

/* Style the counter cards */
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: #f1f1f1;
  margin-bottom:25px;
}
</style>
<body>
     <!-- header-->
 <header>
        <div class="header-area ">
            <div id="sticky-header" class="main-header-area">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-3 col-lg-3">
                            <div class="logo-img">
                                <a href="demo.php">
                                    <img src="img/logo.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="col-xl-9 col-lg-9">
                            <div class="main-menu  d-none d-lg-block">
                            <nav>
                                    <ul id="navigation">
                                        <li><a class="active" href="index.php">home</a></li>
                                        <li><a href="card_template.php">Invitation Card <i class="ti-angle-down"></i></a>
                                            <ul class="submenu">
                                                <li><a href="invitation.php">RSVP</a></li>
                                                <li><a href="upload_file.php">Send invitation_card</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="guest_list.php">Wedding Guest List</a></li>
                                        <li><a href="table.php">Table Seating Chart</a></li>
                                        <li><a href="#">Vendor <i class="ti-angle-down"></i></a>
                                            <ul class="submenu">
                                                <li><a href="restaurant.php">Restaurant</a></li>
                                                <li><a href="Photographer.php">Photographer</a></li>
                                            </ul>
                                        </li>
                                        
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="bradcam_area text-center bradcam_bg overlay3">
   <div class="bradcam_text">
       <h3> Table Seating Chart </h3>
   </div>
</div>
</header>
<form action="table.php" method="post">
    <div class="container">
        <div class="row mt-5">
            <div class="col">
                <div class="card mt-5">
                    <div class="card_header">
                    <h2 class="display-6 text-center">Assign Table Seating </h2>
                    <h3> Table No </h3>
                    <select name="table_no">
                                    <option value="">Select a Table</option>


                            <?php 
                                $r2 = mysqli_query($conn, "SELECT * FROM booking WHERE name='$user_name'");
                                if (!$r2) {
                                    die("Error in SQL query: " . mysqli_error($conn));
                                }
                                
                                while ($row = mysqli_fetch_array($r2)) {
                                    $table = $row['table'];
                                }

                                for ($a = 1; $a<=$table ; $a++){
                                    echo"<option value=$a>$a</option>";
                                }
                                
                                ?>
                                
                            </select>          
                            
                </div>
                <div class="card-body">
                    <table class="table table-bordered text-center">
                    <tr style="bg-dark: black;">
                            <td></td>
                            <td> Guest Id</td>
                            <td> Guest name</td>
                            <td> Guest email </td>
                           
                        </tr>
                        <tr>
                        <?php
                           
                           $result = mysqli_query($conn, "SELECT * FROM card WHERE user_name= '$user_name'");
                           while ($row_outer = mysqli_fetch_array($result)) {
                               $guest_name = $row_outer['guest_name'];
                               $guest_email = $row_outer['guest_email'];
                               $id = $row_outer['id'];
               
                               // Check if the guest is not already assigned to a table
                               $isAssigned = false;
                               $result4 = mysqli_query($conn, "SELECT * FROM table_seating");
                               while ($row_inner = mysqli_fetch_array($result4)) {
                                   $guest_name_selected = $row_inner['guest_name'];
               
                                   if ($guest_name_selected == $guest_name) {
                                       $isAssigned = true;
                                       break;
                                   }
                               }
               
                               if (!$isAssigned) {
                           ?>
                                   <tr>
                                       <td><center><input type="checkbox" name="selected_rows[]" value="<?php echo $guest_name; ?>"></center></td>
                                       <td><?php echo $id; ?> </td>
                                       <td><?php echo $guest_name; ?> </td>
                                       <td><?php echo $guest_email; ?> </td>
                                   </tr>
                           <?php
                               }
                           }
                           ?>
                              
                           

                   
                    
                    </table>
                  </form>
                </div>
                <button type="submit" name="submit">Submit</button>
            </div>
           <br/>  
        <div class="row">
<?php
            $result5 = mysqli_query($conn, "SELECT DISTINCT table_no FROM table_seating WHERE user_name= '$user_name'");
            while ($row = mysqli_fetch_array($result5)) {
                $table_no = $row['table_no'];
             ?>  
                <div class="column">
                     <div class="card">

                     <h3>Table no: <?php echo $table_no; ?></h3>

             <?php
                $result6 = mysqli_query($conn, "SELECT * FROM table_seating WHERE user_name= '$user_name' AND table_no='$table_no'");
                while ($row1 = mysqli_fetch_array($result6)) {

                    $guest_name = $row1['guest_name']
            ?>
                   <h3><?php echo  $guest_name; ?></h3>
                   <?php
                }
                ?>
            </div>
        </div>
    <?php
    }
    ?>
</div>
    <br/>
        <!-- footer_start -->
<footer class="footer">
      <div class="footer_top" style="padding:95px;">
          <div class="container">
              <div class="row">
                  <div class="col-xl-12">
                      <div class="quick_links">
                          <ul>
                              <li><a href="#">Home</a></li>
                              <li><a href="#">Our Story</a></li>
                              <li><a href="#">Gallery</a></li>
                              <li><a href="#">Accommodation</a></li>
                              <li><a href="#">Contact</a></li>
                          </ul>
                      </div>
                  </div>
                </div>
              </div>
        </div>
      
  </footer>
  <!-- footer_end -->

   <!-- JS here -->
   <script src="js/vendor/modernizr-3.5.0.min.js"></script>
   <script src="js/vendor/jquery-1.12.4.min.js"></script>
   <script src="js/popper.min.js"></script>
   <script src="js/bootstrap.min.js"></script>
   <script src="js/owl.carousel.min.js"></script>
   <script src="js/isotope.pkgd.min.js"></script>
   <script src="js/ajax-form.js"></script>
   <script src="js/waypoints.min.js"></script>
   <script src="js/jquery.counterup.min.js"></script>
   <script src="js/imagesloaded.pkgd.min.js"></script>
   <script src="js/scrollIt.js"></script>
   <script src="js/jquery.scrollUp.min.js"></script>
   <script src="js/wow.min.js"></script>
   <script src="js/nice-select.min.js"></script>
   <script src="js/jquery.slicknav.min.js"></script>
   <script src="js/jquery.magnific-popup.min.js"></script>
   <script src="js/plugins.js"></script>

   <!--contact js-->
   <script src="js/contact.js"></script>
   <script src="js/jquery.ajaxchimp.min.js"></script>
   <script src="js/jquery.form.js"></script>
   <script src="js/jquery.validate.min.js"></script>
   <script src="js/mail-script.js"></script>

   <script src="js/main.js"></script>


    </script>      
</body>

</html>
