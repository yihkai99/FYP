<?php

include 'config.php';
session_start();
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];

$message = array(); // Initialize the message array

if (isset($_POST['submit'])) {

    $update_pass = mysqli_real_escape_string($conn, $_POST['update_pass']);
    $new_pass = mysqli_real_escape_string($conn, $_POST['new_pass']);
    $confirm_pass = mysqli_real_escape_string($conn, $_POST['confirm_pass']);

    $query=mysqli_query($conn,"SELECT * FROM user_table WHERE id ='$user_id'");
        while($row=mysqli_fetch_array($query)){
            $hashed = $row['password'];
        }

        if (!empty($new_pass) || !empty($confirm_pass)) {
            if (!password_verify($update_pass, $hashed) ){
                $message[] = 'Old password not matched!';
            } elseif ($new_pass != $confirm_pass) {
                $message[] = 'Confirm password not matched!';
            } else {
                $hashed_new_pass = password_hash($new_pass, PASSWORD_DEFAULT);
                mysqli_query($conn, "UPDATE `user_table` SET password = '$hashed_new_pass' WHERE id = '$user_id'") or die('Query failed');
                $message[] = 'Password updated successfully!';
            
        }    
    }    

    if (isset($_FILES['update_image']) && $_FILES['update_image']['error'] == 0) {
        $update_image = $_FILES['update_image']['name'];
        $update_image_size = $_FILES['update_image']['size'];
        $update_image_tmp_name = $_FILES['update_image']['tmp_name'];
        $update_image_folder = 'uploaded_img/'.$update_image;

        if ($update_image_size > 2000000) {
            $message[] = 'image is too large';
        } else {
            $image_update_query = mysqli_query($conn, "UPDATE `user_table` SET image = '$update_image' WHERE id = '$user_id'") or die('query failed');
            if ($image_update_query) {
                move_uploaded_file($update_image_tmp_name, $update_image_folder);
            }
            $message[] = 'image updated successfully!';
        }
    }
    $update_name = mysqli_real_escape_string($conn, $_POST['update_name']);
    $update_email = mysqli_real_escape_string($conn, $_POST['update_email']);

    mysqli_query($conn, "UPDATE `user_table` SET name = '$update_name', email = '$update_email' WHERE id = '$user_id'") or die('query failed');

    $_SESSION['user_name'] = $update_name;
    $_SESSION['user_email'] = $update_email;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="update-profile">
    <?php
    $select = mysqli_query($conn, "SELECT * FROM `user_table` WHERE name = '$user_name'") or die('query failed');
    $email = ''; // Initialize $email outside the loop
    $image = ''; // Initialize $image outside the loop
    if (mysqli_num_rows($select) > 0) {
        while ($row = mysqli_fetch_array($select)) {
            $email = $row['email'];
            $image = $row['image'];
        }
    }
    ?>
    <form action="update_profile.php" method="POST" enctype="multipart/form-data">
        <?php
        if ($image == '') {
            echo '<img src="images/default-avatar.png">';
        } else {
            echo '<img src="uploaded_img/'.$image.'">';
        }
        if (isset($message)) {
            foreach ($message as $message) {
                echo '<div class="message">'.$message.'</div>';
            }
        }

        ?>
        <div class="flex">
            <div class="inputBox">
                <span>Username:</span>
                <input type="text" name="update_name" value="<?php echo $user_name; ?>" class="box">
                <span>Your Email:</span>
                <input type="email" name="update_email" value="<?php echo $email; ?>" class="box">
                <span>Update Your Pic:</span>
                <input type="file" name="update_image" accept="image/jpg, image/jpeg, image/png" class="box">
            </div>
            <div class="inputBox">
                <span>Old Password:</span>
                <input type="password" name="update_pass" placeholder="Enter previous password" class="box">
                <span>New Password:</span>
                <input type="password" name="new_pass" placeholder="Enter new password" class="box">
                <span>Confirm Password:</span>
                <input type="password" name="confirm_pass" placeholder="Confirm new password" class="box">
            </div>
        </div>

        <input type="submit" value="Update Profile" class="btn1" name="submit">
        <a href="home.php" class="delete-btn">Back</a>
    </form>
</div>

</body>
</html>
