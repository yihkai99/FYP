<?php

include 'config.php';
session_start();
$user_name = $_SESSION['user_name'];
$user_id = $_SESSION['user_id'];

$id=@$_GET['id'];
$menu=@$_GET['menu'];
$price=@$_GET['price'];

 if(isset($_POST["booking"])){
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "user_db";
    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    else{
    $name = $_POST['name'];
    $email_address = $_POST['email_address'];
    $phone_number = $_POST['phone_number'];
    $restaurant_type = $_POST['restaurant_type'];
    $restaurant_name = $_POST['restaurant_name'];
    $restaurant_menu = $_POST['restaurant_menu'];
    $restaurant_price = $_POST['restaurant_price'];
    $restaurant_tablelimit = $_POST['restaurant_tablelimit'];
    $photographer = $_POST['photographer'];
    $date = $_POST['date'];
    $time = $_POST['time'];

    $sql = "INSERT INTO booking (`name`, email_address, phone_number, restaurant_type, restaurant_name, restaurant_menu, restaurant_price, `table`, photographer_name, `date`, `time`,`status`) 
    VALUES ('$name', '$email_address', '$phone_number', '$restaurant_type', '$restaurant_name', '$restaurant_menu', '$restaurant_price', '$restaurant_tablelimit', '$photographer', '$date', '$time','waiting for approval')";


                if (mysqli_query($conn, $sql)) {
                    echo "<script> alert('Your booking is successfully booked!');window.location.replace('index.php'); </script>";
                }
                else {
                    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
                }
            }
            mysqli_close($conn);
        
    }

        ?>

                
<!doctype html>
<html class="no-js" lang="zxx">

<head>
   <meta charset="utf-8">
   <meta http-equiv="x-ua-compatible" content="ie=edge">
   <title>Weeding</title>
   <meta name="description" content="">
   <meta name="viewport" content="width=device-width, initial-scale=1">

   <!-- <link rel="manifest" href="site.webmanifest"> -->
   <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">
   <!-- Place favicon.ico in the root directory -->

   <!-- CSS here -->
   <link rel="stylesheet" href="css/bootstrap.min.css">
   <link href="css/bootstrap.css" rel="stylesheet">
   <link rel="stylesheet" href="css/owl.carousel.min.css">
   <link rel="stylesheet" href="css/magnific-popup.css">
   <link rel="stylesheet" href="css/font-awesome.min.css">
   <link rel="stylesheet" href="css/themify-icons.css">
   <link rel="stylesheet" href="css/nice-select.css">
   <link rel="stylesheet" href="css/flaticon.css">
   <link rel="stylesheet" href="css/animate.css">
   <link rel="stylesheet" href="css/slicknav.css">
   <link rel="stylesheet" href="css/style.css">
   <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia&effect=neon|outline|emboss|shadow-multiple">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" 
                integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" 
                crossorigin="anonymous"/>

    
    <style>
     
        .title p{
            text-align:center;
            padding-top:30px;
            font-size:40px;
            font-weight:bold;
            color:black;
            font-family: "sofia", sans-serif;
        }
        .my-1 mr-2{
            padding-top:30px;
        }
       
       /*register form*/
        form{
            padding: 0px 100px 0px 100px;
        }
        .form-label{
            margin-top: 20px;
            font-weight: bold;
        }
       
        .btn {
            font-size: 20px;
           
            color: black;
            padding: 16px 32px;
            font-weight: bold;
            cursor: pointer;
            margin-bottom: 70px;
            margin-top: 20px;
        }
        .btn:hover{
            font-size: 20px;
            color: black;
            padding: 16px 32px;
            font-weight: bold;
            cursor: pointer;
            margin-bottom: 70px;
            margin-top: 20px;
       }
       .form-control{
            border-radius: .5rem;
            border:#33485d solid;
            padding : 15px 15px 15px 15px;
       }
       ::placeholder{
            font-size: 20px;
            
       }
       .dropdown {
        float: left;
        overflow: hidden;
      }

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 15px 25px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
  width: 130px;
}
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 190px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
  margin-top: -10px;
  padding-right: 10px;
  padding-left: 10px;
  padding-top: 5px;
  padding-bottom: 5px;
 
}
 .dropdown-content a {
  float: none;
  color: black;
  padding: 0px 0px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}

   .menu-bar{
        background-image: linear-gradient(-90deg,#9eb4ca ,#f6f8fa);
    }
    .navbar-nav{
        margin-left: 40px;
    }
    .navbar-nav a:link {
            font-family: Georgia;
            font-size: 22px;
            text-decoration: none;
            text-align: center;
        }
        .navbar-light .navbar-nav .nav-link{
            color: black;
        }
        .navbar-light .navbar-nav .nav-link:visited {
            color: black;
        }
        .navbar-light .navbar-nav .nav-link:hover{
             font-weight:  600;
            border-bottom: 1px solid #ffffff;
        }
        @media screen and (min-width: 992px){
            .navbar-brand img{
                width: 100px;
            }
            .navbar .container-fluid{
                flex-direction: column;
            }
            .navbar .navbar-nav .nav-item{
                padding: .5em 1em;
            }
        }
        .navbar-brand{
            margin-right: 0px;
        }
        #aboutUs{
            padding: 30px 70px 10px 70px;
            text-align: justify;
            line-height: 30px;
        }
        #aboutUs_part2{
            padding: 10px 70px 30px 70px;
            text-align: justify;
            line-height: 30px;
        }
        footer{
            width:100%;
            text-align: center;
            background-color: #475993;
            color: white;
            padding: 10px 0px 10px 0px;
        }
        .navbar-toggler {
           border: 0 !important;
       }
       .navbar-toggler:focus,
       .navbar-toggler:active,
       .navbar-toggler-icon:focus {
           outline: none !important;
           box-shadow: none !important;
           border: 0 !important;
           align-content: right;
       }

       /* Lines of the Toggler */
       .toggler-icon{
           width: 30px;
           height: 3px;
           background-color: #e74c3c;
           display: block;
           transition: all 0.2s;
       }

       /* Adds Space between the lines */
       .middle-bar{
           margin: 5px auto;
       }

       /* State when navbar is opened (START) */
       .navbar-toggler .top-bar {
           transform: rotate(45deg);
           transform-origin: 10% 10%;
       }

       .navbar-toggler .middle-bar {
           opacity: 0;
           filter: alpha(opacity=0);
       }

       .navbar-toggler .bottom-bar {
           transform: rotate(-45deg);
           transform-origin: 10% 90%;
       }
       /* State when navbar is opened (END) */

       /* State when navbar is collapsed (START) */
       .navbar-toggler.collapsed .top-bar {
           transform: rotate(0);
       }

       .navbar-toggler.collapsed .middle-bar {
           opacity: 1;
           filter: alpha(opacity=100);
       }

       .navbar-toggler.collapsed .bottom-bar {
           transform: rotate(0);
       }
       /* State when navbar is collapsed (END) */

       /* Color of Toggler when collapsed */
       .navbar-toggler.collapsed .toggler-icon {
           background-color: #777777;
       }
     
       /*end of menu CSS*/
    
       
   
    @media only screen and (max-width: 600px) {
        .navbar-nav{
             text-align: center;
            margin-left: 0px;
            
        }
        .logout{
           float:right; 
           margin-top: -25px; 
           margin-left: 200px;
           width: 100px;
       }
    }
    
</style>
<!-- header-->
<header>
        <div class="header-area ">
            <div id="sticky-header" class="main-header-area">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-3 col-lg-3">
                            <div class="logo-img">
                                <a href="demo.php">
                                    <img src="img/logo.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="col-xl-9 col-lg-9">
                            <div class="main-menu  d-none d-lg-block">
                            <nav>
                                    <ul id="navigation">
                                        <li><a class="active" href="index.php">Home</a></li>
                                        <li><a href="card_template.php">Invitation Card <i class="ti-angle-down"></i></a>
                                            <ul class="submenu">
                                                <li><a href="invitation.php">RSVP</a></li>
                                                <li><a href="upload_file.php">Send invitation_card</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="guest_list.php">Wedding Guest List</a></li>
                                        <li><a href="table.php">Table Seating Chart</a></li>
                                        <li><a href="#">Vendor <i class="ti-angle-down"></i></a>
                                            <ul class="submenu">
                                                <li><a href="restaurant.php">Restaurant</a></li>
                                                <li><a href="Photographer.php">Photographer</a></li>
                                            </ul>
                                        </li>
                                        
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="mobile_menu d-block d-lg-none"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!--/ header-->
<!-- bradcam_area  -->
<div class="bradcam_area text-center bradcam_bg overlay3">
   <div class="bradcam_text">
       <h3> Place a Booking </h3>
   </div>
</div>

        <div class="title">
       <p>Book An Apppointment</p>
        
            <p>Personal Details </p>
</div>

<?php

            $query = mysqli_query($conn, "SELECT * FROM user_table WHERE name ='$user_name'");
            while ($row = mysqli_fetch_array($query)) {
                $email_address = $row['email'];
            }
            ?>

            <form action="booking.php" method="POST" class="row g-3 needs-validation" novalidate>
                <div class="col-md-6">
                    <label for="validationCustom02" class="form-label">Name : </label>
                    <input type="text" class="form-control" id="validationCustom02" name="name" value="<?php echo $user_name; ?>" readonly>
                    <div class="valid-feedback">
                        Looks good!
                    </div>
                    <div class="invalid-feedback">
                        Please enter your name.
                    </div>
                </div>

                <div class="col-md-6">
                    <label for="validationCustom03" class="form-label">Email Address : </label>
                    <input type="text" class="form-control" id="validationCustom03" name="email_address" value="<?php echo $email_address; ?>" readonly>
                    <div class="valid-feedback">
                        Looks good!
                    </div>
                    <div class="invalid-feedback">
                        Please enter your email.
                    </div>
                </div>
  

            
            <div class="col-md-6">
                <label for="validationCustom04" class="form-label">Phone Number : </label>
                <input type="text" class="form-control" id="validationCustom04" name="phone_number"placeholder="Enter your phone number" required>
                <div class="invalid-feedback">
                      Please enter your phone number.
                </div>
           </div>

           <div class="col-md-12">  
        <div class="title">
           <p>Restaurant Details </p>
           <br/>
    </div>      
    </div>

    <div class="col-md-6">
       <label for="validationCustom04" class="form-label" for="restaurant_type" >Type of restaurant : </label>
       
       <?php
            $query2=mysqli_query($conn,"SELECT * FROM restaurant WHERE rest_id ='$id'");
            while($row=mysqli_fetch_array($query2))
            {
                $restaurant_type = $row['restaurant_type']; 
            }
        ?>

       <input type="text" class="form-control" id="validationCustom04" name="restaurant_type" value="<?php echo $restaurant_type; ?>" readonly>

    </div>

    <div class="col-md-6">
       <label for="validationCustom04" class="form-label" for="restaurant_name" >Your preferred restaurant : </label>
       
       <?php
            $query3=mysqli_query($conn,"SELECT * FROM restaurant WHERE rest_id ='$id'");
            while($row=mysqli_fetch_array($query3))
            {
                $restaurant_name = $row['restaurant_name']; 
            }
        ?>

       <input type="text" class="form-control" id="validationCustom04" name="restaurant_name" value="<?php echo $restaurant_name; ?>" readonly>

    </div>  
            

    <div class="col-md-6">
        <label class="form-label" for="restaurant_price" >Your preffered package : </label>
       <input type="text" class="form-control" id="validationCustom04" name="restaurant_price" value="RM <?php echo $price; ?>.00" readonly>
    </div>
    
    <div class="col-md-6">
        <label for="validationCustom04" class="form-label">Number of table : </label>
        <?php
            $query4=mysqli_query($conn,"SELECT * FROM restaurant WHERE rest_id ='$id'");
            while($row=mysqli_fetch_array($query4))
            {
                $restaurant_tablelimit = $row['restaurant_tablelimit']; 
            }
        ?>

       <input type="text" class="form-control" id="validationCustom04" name="restaurant_tablelimit" value="<?php echo $restaurant_tablelimit; ?>">
       
        </div>

    <!--hidden for restaurant menu -->
       <input type="hidden" class="form-control" id="validationCustom04" name="restaurant_menu" value="<?php echo $menu; ?>" readonly>


    <div class="col-md-6" >
    <label class="form-label" for="type" >Please select your preferred photographer : </label>
    <select class="custom-select my-1 mr-sm-2" name="photographer" style="border: 1px solid; padding:0px; padding-left:5px;p" required>
    <option disabled>--Please Choose Your Photographer--</option>
        <?php
            $query2=mysqli_query($conn,"SELECT * FROM photographer");
            while($row=mysqli_fetch_array($query2))
            {
                $name = $row['name']; 

                echo"<option value='$name'>$name</option>";

            }
        ?>
    </select>
    <div class="invalid-feedback">
        Please choose one.
    </div>
</div>  

                
            <div class="col-md-6">
                <label for="validationCustom06" class="form-label">Preferred Date : </label>
                <input type="date" id='date' name="date" class="form-control form-control-lg" name="date" id="validationCustom06" required>
            </div>
            
            <div class="col-md-6">
                <label for="validationCustom7" class="form-label">Preferred Time : </label>             
            <input type="time" id='time' name="time" class="form-control form-control-lg" name="time" id="validationCustom07" required>

            </div>
            
                
           <div class="col-12" style="margin-top: 50px;">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
                <label class="form-check-label" for="invalidCheck"style="margin-left:20px;">
                  Agree to terms and conditions
                </label>
                <div class="invalid-feedback">
                  You must agree before submitting.
                </div>
              </div>
            </div>
           
            <div class="col-6" style="text-align: right;">
              <button class="btn btn-primary" name="booking" type="submit">Submit</button>
            </div>
            
            <div class="col-6">
                <button class="btn btn-primary" type="reset">Reset</button>
            </div>
            
    </form>
       
      <!-- footer_start -->
   <footer class="footer">
      <div class="footer_top">
          <div class="container">
              <div class="row">
                  <div class="col-xl-12">
                      <div class="quick_links">
                          <ul>
                              <li><a href="#">Home</a></li>
                              <li><a href="#">Our Story</a></li>
                              <li><a href="#">Gallery</a></li>
                              <li><a href="#">Accommodation</a></li>
                              <li><a href="#">Contact</a></li>
                          </ul>
                      </div>
                  </div>
              </div>
              </div>
          </div>
      </div>
      <div class="copy-right_text">
          <div class="container">
              <div class="footer_border"></div>
              <div class="row">
                  
              </div>
          </div>
      </div>
  </footer>
  <!-- footer_end -->

   <!-- JS here -->
   <script src="js/vendor/modernizr-3.5.0.min.js"></script>
   <script src="js/vendor/jquery-1.12.4.min.js"></script>
   <script src="js/popper.min.js"></script>
   <script src="js/bootstrap.min.js"></script>
   <script src="js/owl.carousel.min.js"></script>
   <script src="js/isotope.pkgd.min.js"></script>
   <script src="js/ajax-form.js"></script>
   <script src="js/waypoints.min.js"></script>
   <script src="js/jquery.counterup.min.js"></script>
   <script src="js/imagesloaded.pkgd.min.js"></script>
   <script src="js/scrollIt.js"></script>
   <script src="js/jquery.scrollUp.min.js"></script>
   <script src="js/wow.min.js"></script>
   <script src="js/nice-select.min.js"></script>
   <script src="js/jquery.slicknav.min.js"></script>
   <script src="js/jquery.magnific-popup.min.js"></script>
   <script src="js/plugins.js"></script>

   <!--contact js-->
   <script src="js/contact.js"></script>
   <script src="js/jquery.ajaxchimp.min.js"></script>
   <script src="js/jquery.form.js"></script>
   <script src="js/jquery.validate.min.js"></script>
   <script src="js/mail-script.js"></script>

   <script src="js/main.js"></script>
   <script>
    // Example starter JavaScript for disabling form submissions if there are invalid fields
    (function () {
        'use strict';

        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms = document.querySelectorAll('.needs-validation');

        // Loop over them and prevent submission
        Array.prototype.slice.call(forms)
            .forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    if (!form.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                    }

                    form.classList.add('was-validated');
                }, false);
            });
    })();
</script>



</body>
<?php echo $user_name; ?>" readonly>
</html>