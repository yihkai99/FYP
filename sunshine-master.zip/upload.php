<?php
$src = $_FILES["photo"]["tmp_name"];
$imageName = $_FILES["photo"]["name"];
$imageExtension = explode('.', $imageName);
$imageExtension = strtolower(end($imageExtension));
$newImageName = uniqid() . "." . $imageExtension;
$targ = "images/" . $newImageName;
move_uploaded_file($src, $targ);

echo $targ;  
?>